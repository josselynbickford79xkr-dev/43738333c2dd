# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(soname-check src/soname-check.cpp)
set_property(TARGET soname-check PROPERTY CXX_STANDARD 11)
target_link_libraries(soname-check lionss pthread)

add_executable(binary-size src/binary-size.cpp)
set_property(TARGET binary-size PROPERTY CXX_STANDARD 11)
target_link_libraries(binary-size lionss pthread)

add_executable(export-map-check src/export-map-check.cpp)
set_property(TARGET export-map-check PROPERTY CXX_STANDARD 11)
target_link_libraries(export-map-check lionss pthread)

add_executable(cross-android src/cross-android.cpp)
set_property(TARGET cross-android PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-android lionss pthread)

add_executable(incremental-build src/incremental-build.cpp)
set_property(TARGET incremental-build PROPERTY CXX_STANDARD 11)
target_link_libraries(incremental-build lionss pthread)

add_executable(tech-debt-report src/tech-debt-report.cpp)
set_property(TARGET tech-debt-report PROPERTY CXX_STANDARD 11)
target_link_libraries(tech-debt-report lionss pthread)

add_executable(submodule-sync src/submodule-sync.cpp)
set_property(TARGET submodule-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(submodule-sync lionss pthread)

add_executable(structure-aware-fuzz src/structure-aware-fuzz.cpp)
set_property(TARGET structure-aware-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(structure-aware-fuzz lionss pthread)

add_executable(decoder-fuzz src/decoder-fuzz.cpp)
set_property(TARGET decoder-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(decoder-fuzz lionss pthread)

add_executable(package-msi src/package-msi.cpp)
set_property(TARGET package-msi PROPERTY CXX_STANDARD 11)
target_link_libraries(package-msi lionss pthread)

add_executable(semgrep src/semgrep.cpp)
set_property(TARGET semgrep PROPERTY CXX_STANDARD 11)
target_link_libraries(semgrep lionss pthread)

add_executable(system-tests src/system-tests.cpp)
set_property(TARGET system-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(system-tests lionss pthread)

add_executable(valgrind-massif src/valgrind-massif.cpp)
set_property(TARGET valgrind-massif PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-massif lionss pthread)

add_executable(dependency-review src/dependency-review.cpp)
set_property(TARGET dependency-review PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-review lionss pthread)

add_executable(linux-loongarch64 src/linux-loongarch64.cpp)
set_property(TARGET linux-loongarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-loongarch64 lionss pthread)

add_executable(msvc-build src/msvc-build.cpp)
set_property(TARGET msvc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(msvc-build lionss pthread)

add_executable(coverage-gate src/coverage-gate.cpp)
set_property(TARGET coverage-gate PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage-gate lionss pthread)

add_executable(spack-build src/spack-build.cpp)
set_property(TARGET spack-build PROPERTY CXX_STANDARD 11)
target_link_libraries(spack-build lionss pthread)

add_executable(gcov-report src/gcov-report.cpp)
set_property(TARGET gcov-report PROPERTY CXX_STANDARD 11)
target_link_libraries(gcov-report lionss pthread)

add_executable(interop-tests src/interop-tests.cpp)
set_property(TARGET interop-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(interop-tests lionss pthread)

add_executable(fuzz-regression src/fuzz-regression.cpp)
set_property(TARGET fuzz-regression PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-regression lionss pthread)

add_executable(gcc-12 src/gcc-12.cpp)
set_property(TARGET gcc-12 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-12 lionss pthread)

add_executable(determinism-tests src/determinism-tests.cpp)
set_property(TARGET determinism-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(determinism-tests lionss pthread)

add_executable(coroutines-check src/coroutines-check.cpp)
set_property(TARGET coroutines-check PROPERTY CXX_STANDARD 11)
target_link_libraries(coroutines-check lionss pthread)

add_executable(honggfuzz src/honggfuzz.cpp)
set_property(TARGET honggfuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(honggfuzz lionss pthread)

add_executable(migration-tests src/migration-tests.cpp)
set_property(TARGET migration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(migration-tests lionss pthread)

add_executable(package-flatpak src/package-flatpak.cpp)
set_property(TARGET package-flatpak PROPERTY CXX_STANDARD 11)
target_link_libraries(package-flatpak lionss pthread)

add_executable(cyclonedx-sbom src/cyclonedx-sbom.cpp)
set_property(TARGET cyclonedx-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(cyclonedx-sbom lionss pthread)

add_executable(clang-oldest src/clang-oldest.cpp)
set_property(TARGET clang-oldest PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-oldest lionss pthread)

add_executable(aur-package src/aur-package.cpp)
set_property(TARGET aur-package PROPERTY CXX_STANDARD 11)
target_link_libraries(aur-package lionss pthread)

