// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("package msi\n", stdout);
  return lionss_run_workload("package-msi");
}
