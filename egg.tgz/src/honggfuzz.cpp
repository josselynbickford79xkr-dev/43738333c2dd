// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("honggfuzz\n", stdout);
  return lionss_run_workload("honggfuzz");
}
