// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("gcov report\n", stdout);
  return lionss_run_workload("gcov-report");
}
