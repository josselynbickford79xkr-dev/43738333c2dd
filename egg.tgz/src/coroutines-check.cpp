// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("coroutines check"); }
int main(){
  announce();
  return lionss_run_workload("coroutines-check");
}
