// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("aur package"); }
int main(){
  announce();
  return lionss_run_workload("aur-package");
}
