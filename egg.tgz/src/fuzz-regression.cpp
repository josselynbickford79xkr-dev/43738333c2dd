// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("fuzz regression"); }
int main(){
  announce();
  return lionss_run_workload("fuzz-regression");
}
